require.config({
    shim: {
        'datatables': ['jquery','core'],
    },
    paths: {
        'datatables': 'assets/plugins/datatables/datatables.min',
    }
});